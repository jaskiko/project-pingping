package vo;

public class CartInfo {
// ��ٱ��Ͽ� ��� ��ǰ������ ������ Ŭ������ ��ٱ��� ȭ�鿡�� ������ �����͵鵵 ������ �� �ְ� ��
	private int oc_idx, oc_cnt;
	private String oi_id, mi_email, pi_id, oc_option, oc_date;	// ��ٱ��� �÷�
	private String pi_name, pi_img1, br_name, pi_option;	// �߰��� ������ ������
	private int pi_price, pi_stock;
	
	private String mi_name, mi_phone, oi_payment, oi_date, oi_status;
	// ȸ���̸�, ȸ����ȭ��ȣ, �������, ������, �ֹ�����

	public int getOc_idx() {
		return oc_idx;
	}

	public void setOc_idx(int oc_idx) {
		this.oc_idx = oc_idx;
	}

	public int getOc_cnt() {
		return oc_cnt;
	}

	public void setOc_cnt(int oc_cnt) {
		this.oc_cnt = oc_cnt;
	}

	public String getOi_id() {
		return oi_id;
	}

	public void setOi_id(String oi_id) {
		this.oi_id = oi_id;
	}

	public String getMi_email() {
		return mi_email;
	}

	public void setMi_email(String mi_email) {
		this.mi_email = mi_email;
	}

	public String getPi_id() {
		return pi_id;
	}

	public void setPi_id(String pi_id) {
		this.pi_id = pi_id;
	}

	public String getOc_option() {
		return oc_option;
	}

	public void setOc_option(String oc_option) {
		this.oc_option = oc_option;
	}

	public String getOc_date() {
		return oc_date;
	}

	public void setOc_date(String oc_date) {
		this.oc_date = oc_date;
	}

	public String getPi_name() {
		return pi_name;
	}

	public void setPi_name(String pi_name) {
		this.pi_name = pi_name;
	}

	public String getPi_img1() {
		return pi_img1;
	}

	public void setPi_img1(String pi_img1) {
		this.pi_img1 = pi_img1;
	}

	public String getBr_name() {
		return br_name;
	}

	public void setBr_name(String br_name) {
		this.br_name = br_name;
	}

	public String getPi_option() {
		return pi_option;
	}

	public void setPi_option(String pi_option) {
		this.pi_option = pi_option;
	}

	public int getPi_price() {
		return pi_price;
	}

	public void setPi_price(int pi_price) {
		this.pi_price = pi_price;
	}

	public int getPi_stock() {
		return pi_stock;
	}

	public void setPi_stock(int pi_stock) {
		this.pi_stock = pi_stock;
	}

	public String getMi_name() {
		return mi_name;
	}

	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}

	public String getMi_phone() {
		return mi_phone;
	}

	public void setMi_phone(String mi_phone) {
		this.mi_phone = mi_phone;
	}

	public String getOi_payment() {
		return oi_payment;
	}

	public void setOi_payment(String oi_payment) {
		this.oi_payment = oi_payment;
	}

	public String getOi_date() {
		return oi_date;
	}

	public void setOi_date(String oi_date) {
		this.oi_date = oi_date;
	}

	public String getOi_status() {
		return oi_status;
	}

	public void setOi_status(String oi_status) {
		this.oi_status = oi_status;
	}
		
}