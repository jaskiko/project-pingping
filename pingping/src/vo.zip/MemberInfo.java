package vo;

public class MemberInfo {
// �� ���� ȸ�� ������ �����ϱ� ���� Ŭ����
	private String mi_email, mi_pwd, mi_name, mi_nick, mi_phone, mi_birth, mi_gender;
	private String mi_introduce, mi_img, mi_issms, mi_isemail, mi_recommend;
	private String mi_joindate, mi_isactive, mi_lastlogin, mi_outdate;
	private String ma_name, ma_receiver, ma_phone, ma_zip, ma_addr1, ma_addr2, ma_basic;
	private int mi_following, mi_follower, mi_point, ma_idx;
	
	public String getMi_email() {
		return mi_email;
	}
	public void setMi_email(String mi_email) {
		this.mi_email = mi_email;
	}
	public String getMi_pwd() {
		return mi_pwd;
	}
	public void setMi_pwd(String mi_pwd) {
		this.mi_pwd = mi_pwd;
	}
	public String getMi_name() {
		return mi_name;
	}
	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}
	public String getMi_nick() {
		return mi_nick;
	}
	public void setMi_nick(String mi_nick) {
		this.mi_nick = mi_nick;
	}
	public String getMi_phone() {
		return mi_phone;
	}
	public void setMi_phone(String mi_phone) {
		this.mi_phone = mi_phone;
	}
	public String getMi_birth() {
		return mi_birth;
	}
	public void setMi_birth(String mi_birth) {
		this.mi_birth = mi_birth;
	}
	public String getMi_gender() {
		return mi_gender;
	}
	public void setMi_gender(String mi_gender) {
		this.mi_gender = mi_gender;
	}
	public String getMi_introduce() {
		return mi_introduce;
	}
	public void setMi_introduce(String mi_introduce) {
		this.mi_introduce = mi_introduce;
	}
	public String getMi_img() {
		return mi_img;
	}
	public void setMi_img(String mi_img) {
		this.mi_img = mi_img;
	}
	public String getMi_issms() {
		return mi_issms;
	}
	public void setMi_issms(String mi_issms) {
		this.mi_issms = mi_issms;
	}
	public String getMi_isemail() {
		return mi_isemail;
	}
	public void setMi_isemail(String mi_isemail) {
		this.mi_isemail = mi_isemail;
	}
	public String getMi_recommend() {
		return mi_recommend;
	}
	public void setMi_recommend(String mi_recommend) {
		this.mi_recommend = mi_recommend;
	}
	public String getMi_joindate() {
		return mi_joindate;
	}
	public void setMi_joindate(String mi_joindate) {
		this.mi_joindate = mi_joindate;
	}
	public String getMi_isactive() {
		return mi_isactive;
	}
	public void setMi_isactive(String mi_isactive) {
		this.mi_isactive = mi_isactive;
	}
	public String getMi_lastlogin() {
		return mi_lastlogin;
	}
	public void setMi_lastlogin(String mi_lastlogin) {
		this.mi_lastlogin = mi_lastlogin;
	}
	public String getMi_outdate() {
		return mi_outdate;
	}
	public void setMi_outdate(String mi_outdate) {
		this.mi_outdate = mi_outdate;
	}
	public String getMa_name() {
		return ma_name;
	}
	public void setMa_name(String ma_name) {
		this.ma_name = ma_name;
	}
	public String getMa_receiver() {
		return ma_receiver;
	}
	public void setMa_receiver(String ma_receiver) {
		this.ma_receiver = ma_receiver;
	}
	public String getMa_phone() {
		return ma_phone;
	}
	public void setMa_phone(String ma_phone) {
		this.ma_phone = ma_phone;
	}
	public String getMa_zip() {
		return ma_zip;
	}
	public void setMa_zip(String ma_zip) {
		this.ma_zip = ma_zip;
	}
	public String getMa_addr1() {
		return ma_addr1;
	}
	public void setMa_addr1(String ma_addr1) {
		this.ma_addr1 = ma_addr1;
	}
	public String getMa_addr2() {
		return ma_addr2;
	}
	public void setMa_addr2(String ma_addr2) {
		this.ma_addr2 = ma_addr2;
	}
	public String getMa_basic() {
		return ma_basic;
	}
	public void setMa_basic(String ma_basic) {
		this.ma_basic = ma_basic;
	}
	public int getMi_following() {
		return mi_following;
	}
	public void setMi_following(int mi_following) {
		this.mi_following = mi_following;
	}
	public int getMi_follower() {
		return mi_follower;
	}
	public void setMi_follower(int mi_follower) {
		this.mi_follower = mi_follower;
	}
	public int getMi_point() {
		return mi_point;
	}
	public void setMi_point(int mi_point) {
		this.mi_point = mi_point;
	}
	public int getMa_idx() {
		return ma_idx;
	}
	public void setMa_idx(int ma_idx) {
		this.ma_idx = ma_idx;
	}
}
