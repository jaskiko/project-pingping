package vo;

public class MonthlyInfo {
// �ϳ��� �̴�����õ �Խù� ������ �����ϱ� ���� Ŭ����
	private int mr_idx, mr_reply, mr_read, mr_good, ai_idx, last_admin;
	private String mr_title, mr_site, mr_content, mr_location, mr_url;
	private String mr_keyword, mr_imgs, mr_pdtids, mr_info, mr_sdate;
	private String mr_edate, mr_isview, mr_date, last_date;
	
	public int getMr_idx() {
		return mr_idx;
	}
	public void setMr_idx(int mr_idx) {
		this.mr_idx = mr_idx;
	}
	public int getMr_reply() {
		return mr_reply;
	}
	public void setMr_reply(int mr_reply) {
		this.mr_reply = mr_reply;
	}
	public int getMr_read() {
		return mr_read;
	}
	public void setMr_read(int mr_read) {
		this.mr_read = mr_read;
	}
	public int getMr_good() {
		return mr_good;
	}
	public void setMr_good(int mr_good) {
		this.mr_good = mr_good;
	}
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public int getLast_admin() {
		return last_admin;
	}
	public void setLast_admin(int last_admin) {
		this.last_admin = last_admin;
	}
	public String getMr_title() {
		return mr_title;
	}
	public void setMr_title(String mr_title) {
		this.mr_title = mr_title;
	}
	public String getMr_site() {
		return mr_site;
	}
	public void setMr_site(String mr_site) {
		this.mr_site = mr_site;
	}
	public String getMr_content() {
		return mr_content;
	}
	public void setMr_content(String mr_content) {
		this.mr_content = mr_content;
	}
	public String getMr_location() {
		return mr_location;
	}
	public void setMr_location(String mr_location) {
		this.mr_location = mr_location;
	}
	public String getMr_url() {
		return mr_url;
	}
	public void setMr_url(String mr_url) {
		this.mr_url = mr_url;
	}
	public String getMr_keyword() {
		return mr_keyword;
	}
	public void setMr_keyword(String mr_keyword) {
		this.mr_keyword = mr_keyword;
	}
	public String getMr_imgs() {
		return mr_imgs;
	}
	public void setMr_imgs(String mr_imgs) {
		this.mr_imgs = mr_imgs;
	}
	public String getMr_pdtids() {
		return mr_pdtids;
	}
	public void setMr_pdtids(String mr_pdtids) {
		this.mr_pdtids = mr_pdtids;
	}
	public String getMr_info() {
		return mr_info;
	}
	public void setMr_info(String mr_info) {
		this.mr_info = mr_info;
	}
	public String getMr_sdate() {
		return mr_sdate;
	}
	public void setMr_sdate(String mr_sdate) {
		this.mr_sdate = mr_sdate;
	}
	public String getMr_edate() {
		return mr_edate;
	}
	public void setMr_edate(String mr_edate) {
		this.mr_edate = mr_edate;
	}
	public String getMr_isview() {
		return mr_isview;
	}
	public void setMr_isview(String mr_isview) {
		this.mr_isview = mr_isview;
	}
	public String getMr_date() {
		return mr_date;
	}
	public void setMr_date(String mr_date) {
		this.mr_date = mr_date;
	}
	public String getLast_date() {
		return last_date;
	}
	public void setLast_date(String last_date) {
		this.last_date = last_date;
	}
}
